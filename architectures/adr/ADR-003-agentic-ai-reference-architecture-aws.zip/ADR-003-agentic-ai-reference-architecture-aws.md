# ADR-003: Agentic AI Reference Architecture on AWS

**Date:** 2026-02-21
**Status:** Accepted

## Context

Designing production-grade Agentic AI systems on AWS requires a clear reference architecture that addresses orchestration, memory, tool use, security, and observability. Without a defined reference architecture, implementations risk inconsistency, security gaps, and poor scalability.

## Decision

Adopt Amazon Bedrock as the foundational platform for Agentic AI workloads, structured around the following reference architecture layers:

### Core Components

| Layer | AWS Service / Pattern |
|---|---|
| **Agent Orchestration** | Amazon Bedrock Agents / Strands Agents |
| **Foundation Models** | Amazon Bedrock FMs (Claude, Titan, etc.) |
| **Knowledge Base / RAG** | Amazon Bedrock Knowledge Bases + Amazon OpenSearch / Aurora |
| **Memory Persistence** | Amazon DynamoDB (session memory), S3 (long-term state) |
| **Tool / Action Groups** | AWS Lambda (action executors) |
| **Security & Identity** | AWS IAM, Amazon Cognito, VPC endpoints |
| **Observability** | Amazon CloudWatch, AWS X-Ray, Bedrock model invocation logging |
| **Orchestration Protocol** | Model Context Protocol (MCP) |

### Architecture Flow

```
User Request
    │
    ▼
Amazon Bedrock Agent (Orchestrator)
    ├── Retrieves context → Knowledge Base (RAG)
    ├── Executes tools   → Lambda Action Groups
    ├── Persists memory  → DynamoDB / S3
    └── Returns response → User
```

## Tradeoffs

| Consideration | Tradeoff |
|---|---|
| AWS-native lock-in | Simplified integration vs. multi-cloud portability |
| Managed services | Reduced ops overhead vs. less fine-grained control |
| Bedrock pricing | Pay-per-token vs. self-hosted model cost |
| Lambda cold starts | Simplicity vs. latency for time-sensitive actions |

## Consequences

- Establishes a consistent, reusable architecture pattern for all agentic implementations in this repository
- Aligns with AWS Well-Architected Framework principles
- Enables progressive enhancement as AgentCore and Strands Agents mature

## Risk Mitigation

- Apply least-privilege IAM roles per agent and action group
- Enable Bedrock Guardrails for content safety and compliance
- Use VPC endpoints to prevent data exfiltration over public internet
- Log all model invocations for auditability
- Define circuit breakers in Lambda action groups for downstream failures
